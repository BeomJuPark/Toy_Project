#!/bin/bash

sudo setcap cap_sys_admin+ep toy_system


