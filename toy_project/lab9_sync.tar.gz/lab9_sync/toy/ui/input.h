#ifndef _INPUT_H
#define _INPUT_H

int create_input();

#endif /* _INPUT_H */
