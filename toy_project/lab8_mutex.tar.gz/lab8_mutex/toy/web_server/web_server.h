#ifndef _WEB_SERVER_H
#define _WEB_SERVER_H

int create_web_server();

#endif /* _WEB_SERVER_H */
